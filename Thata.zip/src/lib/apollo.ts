import { ApolloClient, InMemoryCache } from "@apollo/client";

export const client = new ApolloClient({
    uri: 'https://api-sa-east-1.graphcms.com/v2/cl4ocz7x41wuo01z23537exfq/master',
    cache: new InMemoryCache()
})