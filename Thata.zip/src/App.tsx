import { Event } from "./pages/Event"

function App() {
  return (
    <Event />
  )
}

export default App