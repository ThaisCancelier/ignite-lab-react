export function Router() {
    return (
        <Routes></Routes>
    )
}